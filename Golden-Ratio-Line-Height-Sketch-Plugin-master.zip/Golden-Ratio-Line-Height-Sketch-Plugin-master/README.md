*****
**Important note:** The plugin has been updated to work with Sketch 3.4+
*****

[Sketch Plugin] 

# Golden Ratio Line Height
Optimize your typography with ease.


#Install
1. Download and extract ZIP of this repo.
2. Copy the plugin ``Golden Line Height.sketchplugin`` in your Sketch plugin folder (use ``Plugins > Reveal Plugins Folder``).
Plugin filename will show up as item in Sketch Plugins menu.
  
#Usage
1. Select one or more text layers in Sketch. 
2. Run ``Plugins > Golden Line Height`` or use ``cmd + L``

<br><br>
Thanks to <a href="http://www.pearsonified.com/typography/">Pearsonified's Golden Ratio Typography Calculator</a> for providing all the math magic stuff! 
